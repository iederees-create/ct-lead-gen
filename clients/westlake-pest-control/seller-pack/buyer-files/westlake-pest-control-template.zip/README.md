# Westlake Pest Control — Pest Control Website Template

A responsive, conversion-focused website template for pest control companies,
exterminators, termite specialists, rodent-control businesses, fumigation
providers, and residential/commercial pest management businesses.

**Live demo:** https://iederees-create.github.io/westlake-pest-control-template/

> "Westlake Pest Control" is a fictional demonstration business. All contact
> details, ratings, statistics, testimonials, and licence/insurance
> statements shown in the demo are sample placeholder content and must be
> replaced with your real, accurate business information before you publish
> a site built from this template. See `disclaimer.html`.

## Features

- Mobile-first responsive layout with a true hamburger navigation menu (no disappearing nav)
- Announcement / emergency-service bar
- Hero with request-a-quote, click-to-call, and WhatsApp CTAs
- Service cards for residential, commercial, termite, rodent, cockroach & ant,
  bed bug, fumigation, and prevention/maintenance services, each with an
  expandable detail panel
- Pest categories, service process timeline, service-area coverage list, map placeholder
- About/team section, "why choose us", sample stats (clearly labelled as
  editable placeholders), fictional sample testimonials
- Accessible FAQ accordion (keyboard operable, ARIA-correct)
- Client-side quote-form validation with WhatsApp message construction and a
  print-friendly quote summary
- Three colour theme presets (Amber Shield, Green Guard, Red Response) switchable at runtime
- Privacy Policy, Terms of Service, and Pest Treatment Disclaimer pages, plus a custom 404 page
- Local SEO metadata, Open Graph tags, and `ProfessionalService` structured data
- `robots.txt`, `sitemap.xml`, favicon, and Open Graph image
- No external CSS/JS/image dependencies — everything is self-contained and loads over relative paths
- Respects `prefers-reduced-motion`; visible keyboard focus states throughout

## File Structure

```
index.html          Main page (all sections)
privacy.html         Privacy Policy (sample)
terms.html           Terms of Service (sample)
disclaimer.html      Pest treatment / demo-content disclaimer
404.html             Custom not-found page
style.css            All styling (CSS custom properties drive theming)
app.js               Renders config-driven content + all interactivity
site-config.js       ← Edit this file to rebrand the site (see below)
robots.txt / sitemap.xml
favicon.svg / og-image.svg
ASSET-LICENSES.txt   Licence/source record for every non-code asset
```

## Configuration (no HTML editing required)

Open `site-config.js` and edit the values under each section:

- `business` — name, logo text, tagline, description
- `contact` — phone, WhatsApp number, email, address, map URL, quote URL
- `emergency` — emergency-line label and enable/disable flag
- `hours` — business hours rows
- `social` — social profile URLs
- `serviceAreas` — list of areas you serve
- `stats` — headline statistics (replace or remove the `[X]` placeholders — do not publish unverifiable numbers)
- `services` — each service's name, summary, detail copy, and starting price
- `pestsTreated` — pest category chips
- `process` — your quote-to-treatment workflow steps
- `team` — technician/staff profiles
- `whyChooseUs` — differentiators
- `testimonials` — replace the fictional samples with real, permission-cleared reviews
- `faqs` — question/answer pairs
- `legal` — licence/insurance statements and disclaimer summary
- `activeTheme` / `themes` — pick `amber-shield`, `green-guard`, or `red-response`, or edit the colour values directly

You should not need to edit `index.html`, `style.css`, or `app.js` for ordinary
business changes — everything above is rendered from `site-config.js` at
runtime.

## Customisation Notes

- Replace the `[Pest]` logo mark and emoji service icons with your own logo/icons if desired.
- Update the Google Maps embed URL in `contact.mapEmbedUrl` to your real service area.
- Review every legal page (`privacy.html`, `terms.html`, `disclaimer.html`) with a qualified professional before publishing — the included text is a generic starting point, not legal advice.
- Do not publish unsupported claims (guaranteed results, "fully insured", "certified", "same-day response", "child/pet-safe", specific ratings, etc.) unless you can verify them for your real business.

## Deployment

**GitHub Pages:** Push this folder to a repository and enable Pages (Settings → Pages → Deploy from branch → `main` / root). All asset paths are relative, so it also works from a subpath.

**Any static host:** This is a plain static site (HTML/CSS/JS, no build step, no server, no dependencies). Upload the files as-is to Netlify, Vercel, S3, cPanel, or any static file host.

**Local preview:** From this folder, run `python3 -m http.server 8000` and open `http://localhost:8000/`.

## Licence

This template is a digital product licensed for use in a single end-business website per purchase (see `LICENSE.txt` in the buyer package). It may not be resold or redistributed as a template itself. See `ASSET-LICENSES.txt` for third-party asset licensing (fonts, etc.).

## Support Limitations

This is a self-service digital template. Support covers template setup/configuration questions only — it does not include custom development, hosting, domain setup, legal review, or business licensing/compliance guidance. See the buyer guide's Support Policy for full details.

## AI Disclosure

This template's code and copy were developed with the assistance of Claude Code (Anthropic). See the included AI-DISCLOSURE document in the buyer package for details.
